# NFL Pulse · iPhone beta 0.2

Proyecciones NFL, estadísticas, disponibilidad, noticias y clima. Aplicación SwiftUI para iOS 17+, núcleo Swift probado por Swift Package Manager y servicio Python opcional de actualización continua.

Consulta [LEEME.md](LEEME.md) para abrir en Xcode, usar la aplicación, probar el motor, ejecutar el servicio y conocer los resultados y límites de esta beta.
